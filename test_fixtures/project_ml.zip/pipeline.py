import torch
def embed_text(text):
    return [0.1, 0.2, 0.3]
